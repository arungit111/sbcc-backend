const express = require("express");
const router = express.Router();

let liveMatches = [
    {
        id: 1,
        match: "SBCC vs Warriors",
        score: "134/5",
        overs: "17.2"
    }
];

// get live matches
router.get("/", (req, res) => {
    res.json(liveMatches);
});

module.exports = router;
